Instructions for the Google App Engine Java demo project:

1. Make sure you have Java 7 installed and set as the default version.
2. Install Eclipse and the Google App Engine Plugin.
3. Right click in Eclipse's project explorer -> New -> Project -> Google -> Web Application Project.
4. After you created the new project, overwrite the zipped files with the ones in your project.


As part of the Startup Programmin course
