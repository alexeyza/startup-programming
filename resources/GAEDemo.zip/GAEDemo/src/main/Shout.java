package main;

import javax.jdo.annotations.IdentityType;
import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.jdo.annotations.PrimaryKey;

@PersistenceCapable(identityType = IdentityType.APPLICATION)
public class Shout {
	@Persistent
	@PrimaryKey
	private String name;
	@Persistent
	private String message;
	
	public Shout(String name, String message){
		this.name = name;
		this.message = message;
	}
	
	public String getMessage() {
		return message;
	}
	public String getName(){
		return name;
	}
}
